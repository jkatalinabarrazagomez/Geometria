package com.example.geometria;

public class Area {


}
